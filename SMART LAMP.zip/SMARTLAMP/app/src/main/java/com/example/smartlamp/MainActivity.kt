package com.example.smartlamp

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.os.Bundle
import android.view.MotionEvent
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.activity.ComponentActivity
import java.io.File
import android.graphics.Color


class MainActivity : ComponentActivity() {
    private lateinit var show: TextView
    private lateinit var mybutton: Button
    private lateinit var textbutton: Button

    @SuppressLint("ClickableViewAccessibility")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        show = findViewById(R.id.textView2)
        //show.text = "hello"
        try {
            check()
            readfile()
        }
        catch(e: Exception){
            println("failed")
        }

//-------------------------- BUTTON -----------------------------------------//
        //#config button
        mybutton = findViewById(R.id.button)
        mybutton.setOnClickListener() {
            val builder = AlertDialog.Builder(this)

            builder.setTitle("แจ้งเตือน")
            builder.setMessage("คุณต้องการดำเนินการต่อหรือไม่?")
            builder.setPositiveButton("ใช่") { dialog, which ->
                var input: EditText = findViewById(R.id.ip)
                val text1 = input.text.toString()
                println(text1)
                config("config.txt", "$text1")
                input.setText("")
            }

            builder.setNegativeButton("ไม่") { dialog, which ->
                dialog.dismiss() // ปิด Dialog
            }

            builder.setCancelable(false)
            val alertDialog: AlertDialog = builder.create()
            alertDialog.show()
        }

        //#button ON
        mybutton = findViewById(R.id.button1)
        mybutton.setOnClickListener() {
            var test_w = telnet()
            var ck = test_w.RED_ON { result ->
                show.text = "$result"
                textbutton = findViewById(R.id.button1)
                textbutton.setTextColor(Color.parseColor("#FFFFFF"))
                textbutton.setBackgroundColor(Color.parseColor("#3bcc31"))

            }
            show.text = "---"
        }

        //#button OFF
        mybutton = findViewById(R.id.button2)
        mybutton.setOnClickListener() {
            var test_w = telnet()
            var ck = test_w.RED_OFF { result ->
                show.text = "$result"
                textbutton = findViewById(R.id.button1)
                textbutton.setTextColor(Color.parseColor("#000000"))
                textbutton.setBackgroundColor(Color.parseColor("#A09F9F"))
            }

            show.text = "---"
        }

        //#RESUME Button
        mybutton = findViewById(R.id.button4)
        mybutton.setOnClickListener() {
            var test_w = telnet()
            var ck = test_w.stat { result ->
                show.text = "$result"
            }
            show.text = "Failed"
        }

        //#PUSH Button
        mybutton = findViewById(R.id.button3)
        mybutton.setOnTouchListener { v, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    var test_w = telnet()
                    var ck = test_w.RED_ON { result ->
                        show.text = "$result"
                        textbutton = findViewById(R.id.button3)
                        textbutton.setTextColor(Color.parseColor("#FF0000"))
                    }
                    //show.text = "Not found"
                    true
                }
                MotionEvent.ACTION_UP -> {
                    var test_w = telnet()
                    var ck = test_w.RED_OFF { result ->
                        show.text = "$result"
                        textbutton = findViewById(R.id.button3)
                        textbutton.setTextColor(Color.parseColor("#000000"))
                    }
                    //show.text = "Not found"

                    true
                }
                else -> false
            }
        }


    }

    //----------------------------Function-----------------------------//
    fun config(fileName: String, value: String){
        try {
            val filename = "/storage/emulated/0/Download/$fileName"
            val value = value
            File(filename).writeText(value)
            println("done.")
            //println("เขียนไฟล์ $fileName สำเร็จแล้ว")
        }
        catch(e: Exception){
            println("failed")
        }
    }
    fun readfile(){
        try{
            val filename = "/storage/emulated/0/Download/config.txt"
            val value = File(filename).readText()
            var input: EditText = findViewById(R.id.ip)
            input.setText(value)
            println(value)
        }
        catch(e: Exception){
            println("failed")
        }
    }
    fun check(){
        try {
            var test_w = telnet()
            var ck = test_w.stat { result ->
                show.text = "$result"
            }
            show.text = "Failed"
        }
        catch(e: Exception){
            show.text = "Failed"
        }
    }
}