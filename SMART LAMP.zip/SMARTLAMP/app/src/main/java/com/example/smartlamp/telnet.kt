package com.example.smartlamp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import java.io.*
import java.net.Socket
import java.nio.charset.Charset
import kotlinx.coroutines.*
import java.io.File

class telnet {
    val filename = "/storage/emulated/0/Download/config.txt"
    val value = File(filename).readText()
    private val hostname = value // เปลี่ยนเป็น IP หรือ hostname ของ Telnet Server ของคุณ
    private val port = 23             // พอร์ต Telnet มาตรฐาน
    private var i = ""

    fun RED_ON(callback: (result: String) -> Unit) {
        GlobalScope.launch(Dispatchers.IO) {
            var socket: Socket? = null
            var reader: BufferedReader? = null
            var writer: BufferedWriter? = null
            var status = "\uD83D\uDD06" // Default error message


            println("Connecting to $hostname:$port...")
            socket = Socket(hostname, port)
            writer = BufferedWriter(OutputStreamWriter(socket.getOutputStream(), Charset.forName("UTF-8")))
            reader = BufferedReader(InputStreamReader(socket.getInputStream(), Charset.forName("UTF-8")))

            writer.write("r"+ "\r\n") // No need to concatenate with ""
            writer.flush()
            writer?.close()
            reader?.close()
            socket?.close()


            callback(status)
        }
    }

    fun RED_OFF(callback: (result: String) -> Unit) {
        GlobalScope.launch(Dispatchers.IO) {
            var socket: Socket? = null
            var reader: BufferedReader? = null
            var writer: BufferedWriter? = null
            var status = "❌" // Default error message


            println("Connecting to $hostname:$port...")
            socket = Socket(hostname, port)
            writer = BufferedWriter(OutputStreamWriter(socket.getOutputStream(), Charset.forName("UTF-8")))
            reader = BufferedReader(InputStreamReader(socket.getInputStream(), Charset.forName("UTF-8")))

            writer.write("x"+ "\r\n") // No need to concatenate with ""
            writer.flush()
            writer?.close()
            reader?.close()
            socket?.close()


            callback(status)
        }
    }

    fun stat(callback: (result: String) -> Unit) {
        GlobalScope.launch(Dispatchers.IO) {
            try {
                var socket: Socket? = null
                var reader: BufferedReader? = null
                var writer: BufferedWriter? = null
                var status = "" // Default error message


                println("Connecting to $hostname:$port...")
                socket = Socket(hostname, port)
                writer = BufferedWriter(
                    OutputStreamWriter(
                        socket.getOutputStream(),
                        Charset.forName("UTF-8")
                    )
                )
                reader = BufferedReader(
                    InputStreamReader(
                        socket.getInputStream(),
                        Charset.forName("UTF-8")
                    )
                )

                writer.write("c" + "\r\n") // No need to concatenate with ""
                writer.flush()
                var responseLine: String?
                responseLine = reader.readLine()
                while (responseLine != null) { // อ่านจนกว่าจะไม่มีข้อมูลค้างอยู่ในบัฟเฟอร์
                    responseLine = reader.readLine()
                    //println("Received: $responseLine")

                    if ("stat" in responseLine) {
                        writer?.close()
                        reader?.close()
                        socket?.close()
                        break
                    }
                }
                if (responseLine != "stat:100") {
                    status = "❌"
                } else {
                    status = "\uD83D\uDD06"
                }
                callback(status)
            }
            catch(e: Exception){
                println("connection failed")
            }
        }
    }



}