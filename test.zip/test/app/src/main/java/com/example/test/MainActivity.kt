package com.example.test

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import android.widget.EditText
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.tooling.preview.Preview
import com.example.test.ui.theme.TestTheme


class MainActivity : ComponentActivity() {
    var i = 0
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val test: TextView = findViewById(R.id.textView)
        test.text = "count"

        val myButton1: Button = findViewById(R.id.button1)
        myButton1.setOnClickListener {
            //test.text = "test button"
            test1()
        }
        val myButton2: Button = findViewById(R.id.button2)
        myButton2.setOnClickListener {
            //test.text = "test button"
            test2()
        }
        val myButton3: Button = findViewById(R.id.button3)
        myButton3.setOnClickListener {
            //test.text = "test button"
            test3()
        }

    }
    fun test1(){
        i = i+1
        val test: TextView = findViewById(R.id.textView)
        test.text = "$i"
    }
    fun test2(){
        i = i-1
        val test: TextView = findViewById(R.id.textView)
        test.text = "$i"
    }
    fun test3(){
        var input: EditText = findViewById(R.id.editText)
        val show = input.text.toString()

        val test: TextView = findViewById(R.id.textView)
        test.text = "$show"
        //System.out.println(show)
    }

}

