package com.example.test_app2

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.activity.result.launch
import androidx.appcompat.app.AppCompatActivity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.io.BufferedReader
import java.io.BufferedWriter
import java.io.OutputStreamWriter
import java.net.Socket
import java.nio.charset.Charset
import java.io.File
import android.content.Context
import android.widget.EditText
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.appcompat.app.AlertDialog

class MainActivity : AppCompatActivity() {
    var i = 0
    private lateinit var show: TextView
    private lateinit var mybutton: Button
    private lateinit var webView: WebView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        show = findViewById(R.id.textView)

//-------------------------- BUTTON -----------------------------------------//
        mybutton = findViewById(R.id.button)
        mybutton.setOnClickListener(){
            countup()
        }
        mybutton = findViewById(R.id.button2)
        mybutton.setOnClickListener(){
            countdown()
        }
        mybutton = findViewById(R.id.button3)
        mybutton.setOnClickListener(){
            val intent = Intent(this, subActivity::class.javaObjectType); //contact subActivity
            startActivity(intent) //active sumActivity
        }
        mybutton = findViewById(R.id.button12)
        mybutton.setOnClickListener(){

            val builder = AlertDialog.Builder(this)

            // กำหนดหัวข้อ
            builder.setTitle("แจ้งเตือน")

            // กำหนดข้อความ
            builder.setMessage("คุณต้องการดำเนินการต่อหรือไม่?")

            // กำหนดปุ่ม Positive (ปุ่มยืนยัน)
            builder.setPositiveButton("ใช่") { dialog, which ->
                var input: EditText = findViewById(R.id.input1)
                val text1 = input.text.toString()
                println(text1)
                writefile("test.txt", "$text1")
                input.setText("")
                //Toast.makeText(applicationContext, "คุณกด ใช่", Toast.LENGTH_SHORT).show()
            }

            // กำหนดปุ่ม Negative (ปุ่มยกเลิก)
            builder.setNegativeButton("ไม่") { dialog, which ->
                //Toast.makeText(applicationContext, "คุณกด ไม่", Toast.LENGTH_SHORT).show()
                dialog.dismiss() // ปิด Dialog
            }

            // กำหนดให้ Dialog ไม่สามารถปิดได้เมื่อคลิกนอกพื้นที่ Dialog (เป็นทางเลือก)
            builder.setCancelable(false)

            // สร้างและแสดง Dialog
            val alertDialog: AlertDialog = builder.create()
            alertDialog.show()
        }
        mybutton = findViewById(R.id.button13)
        mybutton.setOnClickListener(){
            readfile()
        }

        /*
        webView = findViewById(R.id.web1) // อ้างอิง WebView จาก ID ที่กำหนดใน layout
        // กำหนด WebViewClient เพื่อจัดการการนำทางภายใน WebView
        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, url: String?): Boolean {
                // Return false to allow WebView to load the URL itself
                // Return true to open the URL in an external browser or handle it differently
                return false
            }
        }

        // เปิดใช้งาน JavaScript (ถ้าเว็บไซต์ที่คุณต้องการแสดงใช้ JavaScript)
        webView.settings.javaScriptEnabled = true

        // โหลด URL ของเว็บไซต์ที่คุณต้องการแสดง
        val urlToLoad = "https://www.google.com" // เปลี่ยนเป็น URL ที่คุณต้องการ
        webView.loadUrl(urlToLoad)
        */

    }

//--------------------------------------------Utility function-----------------------------------------------------//
    fun countup(){
        i = i+1
        //show = findViewById(R.id.textView)
        show.text = "count: $i"
    }

    fun countdown(){
        i = i-1
        //show = findViewById(R.id.textView)
        show.text = "count: $i"
    }

    fun writefile(fileName: String, value: String){
        try {
            val filename = "/storage/emulated/0/Download/$fileName"
            val value = value
            File(filename).writeText(value)
            println("done.")
            //println("เขียนไฟล์ $fileName สำเร็จแล้ว")
        }
        catch(e: Exception){
            println("failed")
        }

    }
    fun readfile(){
        try{
            val filename = "/storage/emulated/0/Download/test.txt"
            val value = File(filename).readText()
            //show = findViewById(R.id.textView)
            show.text = "$value"
            println(value)
        }
        catch(e: Exception){
            println("failed")
        }

    }

}

