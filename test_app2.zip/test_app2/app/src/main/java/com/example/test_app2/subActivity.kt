package com.example.test_app2
import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.findViewTreeViewModelStoreOwner
import androidx.lifecycle.lifecycleScope
//import kotlinx.coroutines.CoroutineScope
//import kotlinx.coroutines.Dispatchers
//import kotlinx.coroutines.delay
//import kotlinx.coroutines.launch
import kotlinx.coroutines.* // Import CoroutineScope, launch, Job, delay, isActive
import kotlinx.coroutines.withContext
//import com.example.test_app2.telnet.*
import android.view.MotionEvent

private lateinit var mybutton1: Button
private lateinit var show1: TextView
private var counter = 0
private var job: Job? = null

class subActivity : AppCompatActivity(){
    @SuppressLint("ClickableViewAccessibility")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sub)
        val intent = Intent(this, MainActivity::class.java) //contact Mainactiviy
        show1 = findViewById(R.id.textView2)

    //-----------------------------------BUTTON---------------------------------------------------//
        mybutton1 = findViewById(R.id.button4)
        mybutton1.setOnClickListener(){
            counter = 0
            show1.text = "3s Go Home"
            println("3s Go Home")
            lifecycleScope.launch {
                delay(3000)
                startActivity(intent) //Mainactiviy active
                finish() // ปิด SecondActivity
                stopcount()

            }

            //val intent = Intent(this, MainActivity::class.java)
            //startActivity(intent)
            //finish() // ปิด SecondActivity
        }

        mybutton1 = findViewById(R.id.button5)
        mybutton1.setOnClickListener(){
            startcount()
        }

        mybutton1 = findViewById(R.id.button6)
        mybutton1.setOnClickListener(){
            var test_w = telnet()
            var ck = test_w.RED_ON{
                result ->
                show1.text = "$result"
            }
            show1.text = "Not found"
        }

        mybutton1 = findViewById(R.id.button7)
        mybutton1.setOnClickListener(){
            var test_w = telnet()
            var ck = test_w.ALL_OFF {
                result ->


                show1.text = "$result"
            }
            show1.text = "Not found"

        }
        mybutton1 = findViewById(R.id.button8)
        mybutton1.setOnClickListener(){
            var test_w = telnet()
            var ck = test_w.GREEN_ON(){
                result ->
                show1.text = "$result"
            }
            show1.text = "Not found"

        }
        mybutton1 = findViewById(R.id.button9)
        mybutton1.setOnClickListener(){
            var test_w = telnet()
            var ck = test_w.BLUE_ON{
                    result ->
                show1.text = "$result"
            }
            show1.text = "Not found"

        }

        //PUSH BUTTON1
        mybutton1 = findViewById(R.id.button10)
        mybutton1.setOnTouchListener { v, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    // เมื่อกดปุ่มลง
                    show1.text = "P1_ON"
                    var test_w = telnet()
                    var ck = test_w.RED_ON{ }
                    true // คืนค่า true เพื่อบอกว่าเราจัดการ event นี้แล้ว

                }
                MotionEvent.ACTION_UP -> {
                    // เมื่อปล่อยปุ่ม
                    show1.text = "P1_OFF"
                    var test_w = telnet()
                    var ck = test_w.RED_OFF()
                    true // คืนค่า true เพื่อบอกว่าเราจัดการ event นี้แล้ว
                }
                else -> false // สำหรับ event อื่นๆ ให้ส่งต่อ
            }
        }
        //PUSH BUTTON2
        mybutton1 = findViewById(R.id.button11)
        mybutton1.setOnTouchListener { v, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    // เมื่อกดปุ่มลง
                    show1.text = "P2_ON"
                    var test_w = telnet()
                    var ck = test_w.GREEN_ON {  }
                    true // คืนค่า true เพื่อบอกว่าเราจัดการ event นี้แล้ว

                }
                MotionEvent.ACTION_UP -> {
                    // เมื่อปล่อยปุ่ม
                    show1.text = "P2_OFF"
                    var test_w = telnet()
                    var ck = test_w.GREEN_OFF()
                    true // คืนค่า true เพื่อบอกว่าเราจัดการ event นี้แล้ว
                }
                else -> false // สำหรับ event อื่นๆ ให้ส่งต่อ
            }
        }
        //PUSH BUTTON3
        mybutton1 = findViewById(R.id.button14)
        mybutton1.setOnTouchListener { v, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    // เมื่อกดปุ่มลง
                    show1.text = "P3_ON"
                    var test_w = telnet()
                    var ck = test_w.BLUE_ON {  }
                    true // คืนค่า true เพื่อบอกว่าเราจัดการ event นี้แล้ว

                }
                MotionEvent.ACTION_UP -> {
                    // เมื่อปล่อยปุ่ม
                    show1.text = "P3_OFF"
                    var test_w = telnet()
                    var ck = test_w.BLUE_OFF()
                    true // คืนค่า true เพื่อบอกว่าเราจัดการ event นี้แล้ว
                }
                else -> false // สำหรับ event อื่นๆ ให้ส่งต่อ
            }
        }

    }

    //-----------------------------------------function-----------------------------------------------------//
    private fun startcount() {
        job = CoroutineScope(Dispatchers.Main).launch {
            while (isActive) { // ตรวจสอบว่า Coroutine ยังทำงานอยู่หรือไม่
                counter++
                show1.text = "$counter"
                println(counter)
                delay(1000) // รอ 1 วินาที
            }
        }
    }
    fun stopcount() {
        counter = 0
        job?.cancel() // ยกเลิก Coroutine
    }

}