package com.example.test_app2
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import java.io.*
import java.net.Socket
import java.nio.charset.Charset
import kotlinx.coroutines.*

class telnet {
    private val hostname = "192.168.67.194" // เปลี่ยนเป็น IP หรือ hostname ของ Telnet Server ของคุณ
    private val port = 23             // พอร์ต Telnet มาตรฐาน
    private var i = ""

    fun RED_ON(callback: (result: String) -> Unit) {
        GlobalScope.launch(Dispatchers.IO) {
            var socket: Socket? = null
            var reader: BufferedReader? = null
            var writer: BufferedWriter? = null
            var responseFromServer = "RED ON" // Default error message


            println("Connecting to $hostname:$port...")
            socket = Socket(hostname, port)
            writer = BufferedWriter(OutputStreamWriter(socket.getOutputStream(), Charset.forName("UTF-8")))
            reader = BufferedReader(InputStreamReader(socket.getInputStream(), Charset.forName("UTF-8")))

            writer.write("r"+ "\r\n") // No need to concatenate with ""
            writer.flush()
            writer?.close()

            callback(responseFromServer)
        }
    }
    fun GREEN_ON(callback: (result: String) -> Unit) {
        GlobalScope.launch(Dispatchers.IO) {
            var socket: Socket? = null
            var reader: BufferedReader? = null
            var writer: BufferedWriter? = null
            var responseFromServer = "GREEN ON" // Default error message


            println("Connecting to $hostname:$port...")
            socket = Socket(hostname, port)
            writer = BufferedWriter(OutputStreamWriter(socket.getOutputStream(), Charset.forName("UTF-8")))
            reader = BufferedReader(InputStreamReader(socket.getInputStream(), Charset.forName("UTF-8")))

            writer.write("g"+ "\r\n") // No need to concatenate with ""
            writer.flush()
            writer?.close()

            callback(responseFromServer)
        }
    }

    fun BLUE_ON(callback: (result: String) -> Unit) {
        GlobalScope.launch(Dispatchers.IO) {
            var socket: Socket? = null
            var reader: BufferedReader? = null
            var writer: BufferedWriter? = null
            var responseFromServer = "BLUE ON" // Default error message


            println("Connecting to $hostname:$port...")
            socket = Socket(hostname, port)
            writer = BufferedWriter(OutputStreamWriter(socket.getOutputStream(), Charset.forName("UTF-8")))
            reader = BufferedReader(InputStreamReader(socket.getInputStream(), Charset.forName("UTF-8")))

            writer.write("b"+ "\r\n") // No need to concatenate with ""
            writer.flush()
            writer?.close()

            callback(responseFromServer)
        }
    }


    fun ALL_OFF(callback: (result: String) -> Unit) {
        GlobalScope.launch(Dispatchers.IO) {
            var socket: Socket? = null
            var reader: BufferedReader? = null
            var writer: BufferedWriter? = null
            var responseFromServer = "LED OFF" // Default error message


            println("Connecting to $hostname:$port...")
            socket = Socket(hostname, port)
            writer = BufferedWriter(OutputStreamWriter(socket.getOutputStream(), Charset.forName("UTF-8")))
            reader = BufferedReader(InputStreamReader(socket.getInputStream(), Charset.forName("UTF-8")))

            writer.write("f"+ "\r\n") // No need to concatenate with ""
            writer.flush()
            writer?.close()

            callback(responseFromServer)
        }
    }
    fun RED_OFF(){
        GlobalScope.launch(Dispatchers.IO) {
            var socket: Socket? = null
            var reader: BufferedReader? = null
            var writer: BufferedWriter? = null
            println("RED_OFF")
            socket = Socket(hostname, port)
            writer = BufferedWriter(OutputStreamWriter(socket.getOutputStream(), Charset.forName("UTF-8")))
            writer.write("x"+ "\r\n") // No need to concatenate with ""
            writer.flush()
            writer?.close()
        }
    }
    fun GREEN_OFF(){
        GlobalScope.launch(Dispatchers.IO) {
            var socket: Socket? = null
            var reader: BufferedReader? = null
            var writer: BufferedWriter? = null
            println("GREEN_OFF")
            socket = Socket(hostname, port)
            writer = BufferedWriter(OutputStreamWriter(socket.getOutputStream(), Charset.forName("UTF-8")))
            writer.write("y"+ "\r\n") // No need to concatenate with ""
            writer.flush()
            writer?.close()
        }
    }
    fun BLUE_OFF(){
        GlobalScope.launch(Dispatchers.IO) {
            var socket: Socket? = null
            var reader: BufferedReader? = null
            var writer: BufferedWriter? = null
            println("BLUE_OFF")
            socket = Socket(hostname, port)
            writer = BufferedWriter(OutputStreamWriter(socket.getOutputStream(), Charset.forName("UTF-8")))
            writer.write("z"+ "\r\n") // No need to concatenate with ""
            writer.flush()
            writer?.close()
        }
    }

}